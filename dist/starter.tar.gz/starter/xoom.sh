export VLINGO_STARTER_HOME="${PWD}"
java -jar bin/vlingo-xoom-starter-dist.jar
unset VLINGO_STARTER_HOME